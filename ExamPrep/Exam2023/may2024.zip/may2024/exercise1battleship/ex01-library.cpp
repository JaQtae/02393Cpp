#include <iostream>
#include <random>
#include "ex01-library.h"

using namespace std;

// Task 1(a).  Implement this function
Tile **createSea(unsigned int m) {
    return nullptr;
}


// Task 1(b).  Implement this function
void displaySea(Tile **sea, unsigned int m, bool reveal) {
}


// Task 1(c).  Implement this function
bool launchBigMissile(Tile **sea, unsigned int m, unsigned int r, unsigned int c) {
    return false;
}


// Task 1(d).  Implement this function
bool isGameOver(Tile **sea, unsigned int m){
    return false;
}

// Do not modify the following function.
void deleteSea(Tile **sea, unsigned int m) {
    for (unsigned int i = 0; i < m; i++) {
        delete[] sea[i];
    }
    delete[] sea;
}
